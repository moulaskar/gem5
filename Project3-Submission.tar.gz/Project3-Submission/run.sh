scons --force-lto build/ALPHA/gem5.opt -j4
build/ALPHA/gem5.opt --outdir=Project3-Submission/Problem2/dijkstra-Conf1 configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_assoc=16 --repl_policy="LRUIPVRP()" --l2_size=256kB  -c benchmarks/dijkstra/dijkstra_small -o benchmarks/dijkstra/input.dat

build/ALPHA/gem5.opt --outdir=Project3-Submission/Problem2/dijkstra-Conf2 configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_assoc=16 --repl_policy="LRUIPVRP()" --l2_size=1MB  -c benchmarks/dijkstra/dijkstra_small -o benchmarks/dijkstra/input.dat

build/ALPHA/gem5.opt --outdir=Project3-Submission/Problem2/basicmath-Conf1 configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_assoc=16 --repl_policy="LRUIPVRP()" --l2_size=256kB  -c benchmarks/basicmath/basicmath_small 

build/ALPHA/gem5.opt --outdir=Project3-Submission/Problem2/basicmath-Conf2 configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_assoc=16 --repl_policy="LRUIPVRP()" --l2_size=1MB  -c benchmarks/basicmath/basicmath_small
