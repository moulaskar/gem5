#!/bin/sh
basicmath_small > output_small.txt
