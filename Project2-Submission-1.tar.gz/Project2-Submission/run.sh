#scons --force-lto build/ALPHA/gem5.opt -j4
build/ALPHA/gem5.opt --outdir=Project2-Submission/Problem2/FFT_Conf1 configs/example/se.py  --cpu-type=DerivO3CPU --caches --l2cache --bp-type=Gshare8KBP -c benchmarks/FFT/fft -o "4 4096"

build/ALPHA/gem5.opt --outdir=Project2-Submission/Problem2/FFT_Conf2 configs/example/se.py  --cpu-type=DerivO3CPU --caches --l2cache --bp-type=Gshare32KBP -c benchmarks/FFT/fft -o "4 4096"

build/ALPHA/gem5.opt --outdir=Project2-Submission/Problem2/qsort_Conf1 configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=Gshare8KBP -c  benchmarks/qsort/qsort_small -o benchmarks/qsort/input_small.dat

build/ALPHA/gem5.opt --outdir=Project2-Submission/Problem2/qsort_Conf2 configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=Gshare32KBP -c  benchmarks/qsort/qsort_small -o benchmarks/qsort/input_small.dat
